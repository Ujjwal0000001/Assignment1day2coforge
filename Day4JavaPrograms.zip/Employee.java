
// a.1) Employee class to calculate final salary using OOP principles
import java.util.Scanner;

public class Employee {
    private double salary;
    private int hoursPerDay;

    // Method to get initial info
    public void getInfo(double salary, int hoursPerDay) {
        this.salary = salary;
        this.hoursPerDay = hoursPerDay;
    }

    // Method to add bonus based on salary
    public void addSal() {
        if (salary < 500) {
            salary += 10;
        }
    }

    // Method to add bonus based on hours of work
    public void addWork() {
        if (hoursPerDay > 6) {
            salary += 5;
        }
    }

    // Method to print final salary
    public void printSalary() {
        System.out.println("Final Salary: $" + salary);
    }

    // Main method to run the program
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Employee emp = new Employee();

        System.out.print("Enter salary: ");
        double salary = scanner.nextDouble();

        System.out.print("Enter hours of work per day: ");
        int hours = scanner.nextInt();

        emp.getInfo(salary, hours);
        emp.addSal();
        emp.addWork();
        emp.printSalary();

        scanner.close();
    }
}
