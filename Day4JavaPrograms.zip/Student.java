
// b) Student class demonstrating encapsulation and abstraction
import java.util.Scanner;

class Student {
    private String name;
    private int yearOfJoining;
    private String address;

    public Student(String name, int yearOfJoining, String address) {
        this.name = name;
        this.yearOfJoining = yearOfJoining;
        this.address = address;
    }

    public String getName() {
        return name;
    }

    public int getYearOfJoining() {
        return yearOfJoining;
    }

    public String getAddress() {
        return address;
    }
}

public class StudentTest {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        Student[] students = new Student[3];

        for (int i = 0; i < 3; i++) {
            System.out.println("Enter details for Student " + (i + 1) + ":");
            System.out.print("Name: ");
            String name = scanner.nextLine();
            System.out.print("Year of Joining: ");
            int year = Integer.parseInt(scanner.nextLine());
            System.out.print("Address: ");
            String address = scanner.nextLine();
            students[i] = new Student(name, year, address);
        }

        System.out.println("\nName\tYear of joining\tAddress");
        for (Student s : students) {
            System.out.println(s.getName() + "\t" + s.getYearOfJoining() + "\t\t" + s.getAddress());
        }

        scanner.close();
    }
}
