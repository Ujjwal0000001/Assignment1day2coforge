
// 1. Swap two numbers without using a third variable
public class SwapNumbers {
    public static void main(String[] args) {
        int a = 5;
        int b = 10;

        // Swapping without using a third variable
        a = a + b;
        b = a - b;
        a = a - b;

        System.out.println("After swapping:");
        System.out.println("a = " + a);
        System.out.println("b = " + b);
    }
}
