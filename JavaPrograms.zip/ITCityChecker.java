
// 6. Check if entered city is an IT city
import java.util.Scanner;

public class ITCityChecker {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter city name: ");
        String city = scanner.nextLine().trim().toLowerCase();

        switch (city) {
            case "delhi":
            case "mumbai":
            case "kolkatta":
            case "bangalore":
            case "chennai":
            case "hyderabad":
                System.out.println("It is an IT city.");
                break;
            default:
                System.out.println("It is NOT an IT city.");
        }

        scanner.close();
    }
}
