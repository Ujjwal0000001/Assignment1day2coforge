
// 4. Determine password strength
import java.util.Scanner;

public class PasswordStrength {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a password: ");
        String password = scanner.nextLine();

        boolean hasUpper = password.matches(".*[A-Z].*");
        boolean hasLower = password.matches(".*[a-z].*");
        boolean hasDigit = password.matches(".*[0-9].*");
        boolean hasSpecial = password.matches(".*[!@#$%^&*()-+=<>?/{}~|].*");

        if (password.length() >= 8 && hasUpper && hasLower && hasDigit && hasSpecial) {
            System.out.println("Password strength: Strong.");
        } else if (password.length() >= 6 && hasUpper && hasLower && hasDigit) {
            System.out.println("Password strength: Medium.");
        } else {
            System.out.println("Password strength: Weak.");
        }

        scanner.close();
    }
}
